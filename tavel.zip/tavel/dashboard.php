<?php
 include("config/db.php");
?>

<html>
<head>
<title> Admin Panel </title>
<meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
 <link rel="stylesheet" href="css/fontawesome.min.css" type="text/css">
 <link rel="stylesheet" href="css/admin.css" type="text/css">
<link rel="stylesheet" type="text/css" href="m.css">
<body>
 <div class="row">
  <div class="leftcoloumn">
  <div class="heading">
   <h3 style="text-align: center; font-weight: bold; color: black; line-height: 60px;"> Admin Panel </h3>
   </div>
   
   <div class="menu">
    <div class="topnav" id="myTopnav">
	<a href="index.php">Home </a>
	
	 <a href="view.php"> Insert/View</a> 
	 <a href="analytics.php"> Analytics </a>
	 <a href="profile.php"> Profile</a>
   <form action="logout.php">
   <button class="btn btn-danger" style="float: right; margin-right: 10px"> 
   Logout
   </button>
   </form>
   </div> 
	</div>
   </div>
   </div>
  <h4 align="center"> Admin Dashboard </h4>
   <div class="row">
    <div class="col-md-4">
	<div class="cc">
	<?php
	$pc="select * from news";
	$run_p=mysqli_query($con,$pc);
	$count_pc=mysqli_num_rows($run_p);
	?>
	
	<h4> Total Post </h3>
	<span class="badge" style=" background:white">
 <?php echo "$count_pc"; ?>
	</span>
	 </center>
</div>

	</div>
    <div class="col-md-4">
<div class="cc">
	 <center>
	<img src="img/call.png" class="img img-circle" style="height:50px" >
	
		<?php
	$pc1="select * from cat";
	$run_p1=mysqli_query($con,$pc1);
	$count_pc1=mysqli_num_rows($run_p1);
	?>
	<h4> Contact </h3>
	<span class="badge" style=" background:white"> 
	 <?php echo "$count_pc1"; ?>
	</span>
	 </center>	 
	 </div>
	 </div>
    <div class="col-md-4"> 
	<div class="cc">
	 <center>
	<img src="img/pen.png" class="img img-circle" style="height:50px" >
			<?php
	$pc2="select * from contact";
	$run_p2=mysqli_query($con,$pc2);
	$count_pc2=mysqli_num_rows($run_p2);
	?>
	<h4> Categories </h3>
	<span class="badge" style=" background:white">
	<?php echo "$count_pc2"; ?>
	 </span>
	</center>
</div>
	</div>
   </div>
   <br>
   <br>
   <br>
    <h3> Contact us </h3>
	<tr>
	<table class="table table-hover table-striped table-bordered"> 
	<tr>
	<th> S.no </th>
	<th> Name </th>
	<th> Email </th>
	<th> Msg </th>
	</tr>
	<?php
	$pc3="select * from contact";
	$run_p3=mysqli_query($con,$pc3);
	while($row=mysqli_fetch_array($run_p3))
	{
		$name=$row['name'];
		$email=$row['email'];
		$msg=$row['msg'];
			
		?>
	<tr>
	
	<th> 1 </th>
	<th><?php echo "$name"; ?></th>
	<th> <?php echo "$email"; ?> </th>
	<th> <?php echo "$msg"; ?> </th>
	
	</tr>
	
	<?php
	}
	
	?>
   </div>
  
   
   </div>
</head> 
</html>

   
</div>
