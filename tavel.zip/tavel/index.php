<?php
include("config/db.php");
?>
<html>
<head>
  <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
 <link rel="stylesheet" href="css/fontawesome.min.css" type="text/css">
 <link rel="stylesheet" href="css/style.css" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="m.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<div class="header">
  <h2>Content Management System</h2>
</div>
<div class="topnav" id="myTopnav">
 <a href="index.html" >Home</a>
  <a href="tavel.html">Travels</a>
  <a href="product.html">Product</a>
  <a href="technology.html">Technology</a>
  <a href="event.html">Events</a>
  <a href="achievements.html">Achievements</a>
  <a href="awards.html">Awards</a>
<a href="tstimonials.html">Testimonials</a>
<a href="dashboard.php "> &nbsp Admin </a></li>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

    <<div class="row">
  <div class="leftcolumn">
    <div class="card">
     <h2>TRAVELS</h2>
      <div> <a href="tavel.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
       </div>
<div class="card">
      <h2>PRODUCTS</h2>
      <div> <a href="product.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
    
    </div>
    <div class="card">
     <h2>TECHNOLOGY</h2>
      <div> <a href="technology.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
     </div>
 <div class="card">
     <h2>EVENTS</h2>
      <div> <a href="event.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
  
    </div>
  </div>
<div class="middlecolumn">
    <div class="card">
    <h2>ACHIEVEMENTS</h2>
      <div> <a href="achievements.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
    </div>
<div class="card">
      <h2>AWARDS</h2>
      <div> <a href="awards.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
     
    </div>
    <div class="card">
      <h2>TESTIMONIALS</h2>
      <div> <a href="tstimonials.html">
<img border="0" src="image/rm.jpg"  height="200px">
</a></div>
      <p>Group travel has seen no innovation since its inception. Almost all airlines in the world manage their group bookings manually.</p>
     </div>
  </div>
  <div class="rightcolumn">
   <div class="card">
  <div class="search-container">
    <form action="/action_page.php">
   <input type="text" placeholder="Search.." name="search"> 
<button type="submit">submit</button>
    </form>
  </div>
</div>
    <div class="card">
      <h3>Resent Post</h3>
      <div class="fakeimg">Image</div><br>
      <div class="fakeimg">Image</div><br>
      <div class="fakeimg">Image</div>
    </div>
 <div class="card">
      <h3>Categories</h3>
<ul>
<li><a href="tavel.html">Travel</a></li><br>
<li><a href="product.html">Products</a></li><br>
<li><a href="technology.html">Technology</a></li><br>
<li><a href="event.html">Events</a></li><br>
<li><a href="achievements.html">Achievements</a></li><br>
<li><a href="awards.html">Awards</a></li><br>
<li><a href="tstimonials.html">Testimonials</a></li><br>
   
</ul> 
    </div>
<div class="card">
      <h2> ASK US TO POST</h2>
  <p>commend <a href="login.html">here.</a></p>
</div>
</div>
</div>

<div class="footer">
<table align="center">
<tr><td align="center">
<a href="https://www.facebook.com/Infiniti.Atyourprice/" class="fa fa-facebook"></a>
<a href="https://twitter.com/infiniti_soft?lang=en" class="fa fa-twitter"></a>
<a href="#" class="fa fa-instagram"></a></td></tr>
<tr><td><h2> About</h2></td>
<td><h2> Contact</h2></td>
<td><h2> Privercy</h2></td>
</tr>
</table>
</div>
	<div class="post">
	<?php
	$select="select * from news order by id Desc limit 0,4";
	$select_run=mysqli_query($con,$select);
	$count=mysqli_num_rows($select_run);
	if($count>0)
	{
		while($row=mysqli_fetch_array($select_run))
		{
			$id=$row[ 'id' ]; 
		 $name=$row[ 'Name' ]; 	
		 $text=$row[ 'Text' ]; 	
		 $date=$row[ 'Date' ]; 	
		 $img=$row[ 'img' ]; 	
			
	
	?>
	<br>
	<br>
	<div class="row">
	<div class="col-md-4" style="border:0px solid">  
	<img src="img/<?php echo $img ?>" class="img img-thumbnail" >
	</div>
	<div class="col-md-8">
   <h5 style="font:weight: bold;color:black"> <?php echo $name ?> </h5>
   <h6 style="float:right;"> <?php echo $date ?> </h6>
   <br>
    <p style="text-align:justify" ><?php echo $text ?> 
	</p>
	</div>
	<a href="viewnews.php?id=<?php echo $id;?>"><button class="btn btn-info" style="float:right;">read more</button></a>
 </div>
	<?php }}

else
{
	echo "<h4><center>Sorry No Post Available</center></h4>";
}

?>
	
 </div>
  
	 </div>
	

	<?php include("include/side.php");
	?>
	<div class="footer">
 
</div>
</div>
</div>
</body>
</html>